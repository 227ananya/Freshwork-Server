import {getTransaction} from "./generateControllerParams.js";
import Ajv from"ajv";
const ajv = new Ajv()
// From here we will validate the incoming datas. If the datas are correct then we will proceed for functionality. Else throw error.
export const controllerHandler=async({req,res,schema,controller})=> {
    // Transaction is a sequalize method. 
    //If you are doing any modifications in the database then without transaction commit the changes will not get saved.
    var transaction = await getTransaction();
    var params= {
        body: req.body,
        params: req.params,
        queryString: req.query,
        transaction
    }
    if(schema){
        validateSchema(res,schema,params,controller)
    } else {
        const response=await controller(params);
        res.status(response.status).send(response.message);
    }

}

async function validateSchema(res,schema,params,controller) {
    let payload = { ...(params.body ? params.body : {}), ...params.params, ...(params.query ? params.query : {}) };
    const validate = ajv.compile(schema)
    const valid = validate(payload)
    if (!valid) {
        console.log(validate.errors)
        var error= validate.errors[0].instancePath+" "+validate.errors[0].message
        res.status(400).send({errorMessage:error})
    } else {
        const response=await controller(params);
        res.status(response.status).send(response.message);
    }

}