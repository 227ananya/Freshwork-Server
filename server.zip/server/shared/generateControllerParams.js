import { sequelize } from "../shared/sequelize.js";

/**
 * Transaction is very important in sequelize to do any action in the database. Without transacrion created,updated,deleted 
 * operations will not get saved in the db 
 */
export const getTransaction = async ()=> {
    return await sequelize.transaction();
};

