import { createHash } from "crypto";

/**
 * generate a salted sha256 string.
 */
export const generateSha256Password = (key) => {
    const secret = process.env.SHA256_PASSWORD_SALT;
    return createHash("sha256").update(key + secret).digest("hex");
};
