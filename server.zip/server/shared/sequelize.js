import { Sequelize } from "sequelize";

export const sequelize = new Sequelize(
   'test', // Connection name
   'root', // username
   '', //password
    {
      host: '127.0.0.1',
      dialect: 'mysql'
    }
  );