import express from 'express';
import {sequelize}  from './shared/sequelize.js';
import {userRouter} from"../server/services/UserService/server.js";
import bodyParser from "body-parser";
// import 'dotenv/config';

/* 
DotEnv is used to read datas from environment files. 
By not keeping the important credentials everywhere in the code we can avoid misuse of our credentials. 
*/
import dotenv from 'dotenv';
import { customerRouter } from './services/CustomerServices/server.js';
import { orderRouter } from './services/OrderServices/server.js';
dotenv.config({path: "./env/dev.env"});


// express connection establish
const app = express();
const PORT = 3000;

// BodyParser is used to read request body
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())

app.listen(PORT, function (err) {
	if (err) console.log(err);
	console.log("Server listening on PORT", PORT);
});

// Testing API
app.get('/', function (req, res, next) {
	res.send("Router Working");
})

// Establish the sequelize connection and sync the tables
sequelize.authenticate().then(() => {
   console.log('Connection has been established successfully.');
}).catch((error) => {
   console.error('Unable to connect to the database: ', error);
});
sequelize.sync().then(() => {
    console.log('Tables created successfully!');
}).catch((error) => {
    console.error('Unable to create table : ', error);
});

// If endpoint starts with "/users" it will point to user services. And like this we will implement microservices
app.use("/users",userRouter)
app.use("/customers",customerRouter)
app.use("/orders",orderRouter)

