import { DataTypes } from'sequelize';
import {sequelize} from "../shared/sequelize.js";

export const CustomerOrders = sequelize.define('CustomerOrders', {
  // Model attributes are defined here
  uuid: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
    allowNull: false
  },
  customer_uuid: {
    type: DataTypes.UUID,
    allowNull: false
  },
  shipping_address: {
    type: DataTypes.STRING,
    allowNull: false
  },
  billing_address: {
    type: DataTypes.STRING,
    allowNull: false
  },
  status: {
    type: DataTypes.STRING,
    allowNull: false
  },
  item_totals: {
    type: DataTypes.STRING,
    allowNull: false
  },
  total_amount: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  // Other model options go here
});

// `sequelize.define` also returns the model
console.log(CustomerOrders === sequelize.models.CustomerOrders); // true