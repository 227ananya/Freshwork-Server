import { DataTypes } from'sequelize';
import {sequelize} from "../shared/sequelize.js";

export const OrderItems = sequelize.define('OrderItems', {
  // Model attributes are defined here
  uuid: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
    allowNull: false
  },
  order_uuid: {
    type: DataTypes.UUID,
    allowNull: false
  },
  item_name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  item_quantity: {
    type: DataTypes.STRING,
    allowNull: false
  },
  price: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  // Other model options go here
});

// `sequelize.define` also returns the model
console.log(OrderItems === sequelize.models.OrderItems); // true