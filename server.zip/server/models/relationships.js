import { Customer,CustomerOrders,OrderItems,PaymentDetails } from "./module.js";
/**
 * This contains all the relationships with the tables
 */

CustomerOrders.belongsTo(Customer, { foreignKey: "customer_uuid", onDelete: "restrict" });
Customer.hasMany(CustomerOrders, { foreignKey: "customer_uuid", onDelete: "restrict" });

OrderItems.belongsTo(CustomerOrders, { foreignKey: "order_uuid", onDelete: "restrict" });
CustomerOrders.hasMany(OrderItems, { foreignKey: "order_uuid", onDelete: "restrict" });

PaymentDetails.belongsTo(CustomerOrders, { foreignKey: 'order_uuid', onDelete: "restrict" });


