import { DataTypes } from'sequelize';
import {sequelize} from "../shared/sequelize.js";

export const PaymentDetails = sequelize.define('PaymentDetails', {
  // Model attributes are defined here
  uuid: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
    allowNull: false
  },
  order_uuid: {
    type: DataTypes.UUID,
    allowNull: false
  },
  payment_method: {
    type: DataTypes.STRING,
    allowNull: false
  },
  status: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  // Other model options go here
});

// `sequelize.define` also returns the model
console.log(PaymentDetails === sequelize.models.PaymentDetails); // true