import { CustomerOrders } from "../../../models/customerOrders.js";
import { Customer } from "../../../models/customers.js";

export const createOrders=async(params)=>{
    const transaction= params.transaction;
    var customers=await Customer.findAll();
    var customerOrders= customers.map((each)=> {
        return {
            customer_uuid: each.uuid,
            shipping_address: "62021 Davis Wells,24569",
            billing_address: "62021 Davis Wells,24569",
            status:"SUCCESS",
            item_totals: Math.floor((Math.random() * 100) + 1),
            total_amount: Math.floor((Math.random() * 100000) + 1)
        }
    })
    await CustomerOrders.bulkCreate(customerOrders);
    await transaction.commit();
    return {
        status: 201,
        message: {
            message: "Created"
        }
    }
    
}