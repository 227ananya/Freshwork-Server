import { CustomerOrders } from "../../../models/customerOrders.js";
import { Customer } from "../../../models/customers.js";
import { OrderItems } from "../../../models/orderItems.js";

export const getCustomerOrderDetails=async(params)=>{
    var orders=await Customer.findAll({
        // where: {
        //     uuid: body.uuid
        // },
        include: [{
            model: CustomerOrders,
            required: false,
            include: [{
                model: OrderItems,
                required: false,
            }]
        }]
    });
    return {
        status: 200,
        message: {
            message: "Ok",
            data: orders
        }
    }
    
}