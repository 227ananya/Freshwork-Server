import { CustomerOrders } from "../../../models/customerOrders.js";
import { PaymentDetails } from "../../../models/paymentDetails.js";

export const createOrderPaymentInfo=async(params)=>{
    const transaction= params.transaction;
    var customers=await CustomerOrders.findAll();
    var orderItems= customers.map((each)=> {
        return {
            order_uuid: each.uuid,
            payment_method: "Payment"+Math.floor((Math.random() * 10) + 1),
            status: "SUCCESS"
        }
    })
    await PaymentDetails.bulkCreate(orderItems);
    await transaction.commit();
    return {
        status: 201,
        message: {
            message: "Created"
        }
    }
    
}