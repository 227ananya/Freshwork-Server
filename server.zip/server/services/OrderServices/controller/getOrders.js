import { CustomerOrders } from "../../../models/customerOrders.js";

export const getOrders=async(params)=>{
    var orders=await CustomerOrders.findAll({
        where: {
            customer_uuid: params.body.uuid
        }
    });
    return {
        status: 200,
        message: {
            message: "Ok",
            data: orders
        }
    }
    
}