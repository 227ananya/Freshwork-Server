import { CustomerOrders } from "../../../models/customerOrders.js";
import { OrderItems } from "../../../models/orderItems.js";

export const createOrderItems=async(params)=>{
    const transaction= params.transaction;
    var customers=await CustomerOrders.findAll();
    var orderItems= customers.map((each)=> {
        return {
            order_uuid: each.uuid,
            item_name: "Item"+Math.floor((Math.random() * 10) + 1),
            item_quantity: JSON.stringify(Math.floor((Math.random() * 100) + 1)),
            price: JSON.stringify(Math.floor((Math.random() * 100000) + 1)),
        }
    })
    await OrderItems.bulkCreate(orderItems);
    await transaction.commit();
    return {
        status: 201,
        message: {
            message: "Created"
        }
    }
    
}