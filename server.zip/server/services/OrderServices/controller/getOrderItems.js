import { OrderItems } from "../../../models/orderItems.js";

export const getOrderItems=async(params)=>{
    var orders=await OrderItems.findAll();
    return {
        status: 200,
        message: {
            message: "Ok",
            data: orders
        }
    }
    
}