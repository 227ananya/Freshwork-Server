import { PaymentDetails } from "../../../models/paymentDetails.js";

export const getOrderPaymentInfo=async(params)=>{
    var orders=await PaymentDetails.findAll();
    return {
        status: 200,
        message: {
            message: "Ok",
            data: orders
        }
    }
    
}