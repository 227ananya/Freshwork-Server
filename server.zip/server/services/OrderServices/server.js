import * as express from 'express'
import { controllerHandler } from '../../shared/controllerHandler.js';
import { createOrders } from './controller/createOrders.js';
import { getOrders } from './controller/getOrders.js';
import { createOrderItems } from './controller/createOrderItems.js';
import { getOrderItems } from './controller/getOrderItems.js';
import { createOrderPaymentInfo } from './controller/createOrderPaymentInfo.js';
import { getOrderPaymentInfo } from './controller/getOrderPaymentInfo.js';
import { getCustomerOrderDetails } from './controller/getCustomerOrderDetails.js';
const router = express.Router();

router.post('/createOrders',(req,res)=> {
    controllerHandler({
        req,res,
        controller: createOrders
    })
})
router.get('/getOrders',(req,res)=> {
    controllerHandler({
        req,res,
        controller: getOrders
    })
})
router.post('/createOrderItems',(req,res)=> {
    controllerHandler({
        req,res,
        controller: createOrderItems
    })
})
router.get('/getOrderItems',(req,res)=> {
    controllerHandler({
        req,res,
        controller: getOrderItems
    })
})
router.post('/createOrderPaymentInfo',(req,res)=> {
    controllerHandler({
        req,res,
        controller: createOrderPaymentInfo
    })
})
router.get('/getOrderPaymentInfo',(req,res)=> {
    controllerHandler({
        req,res,
        controller: getOrderPaymentInfo
    })
})
router.get('/getCustomerOrderDetails',(req,res)=> {
    controllerHandler({
        req,res,
        controller: getCustomerOrderDetails
    })
})

const orderRouter=router;
export {orderRouter};
