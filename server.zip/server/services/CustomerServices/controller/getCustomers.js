import { Customer } from "../../../models/customers.js"

export const getCustomers=async(params)=>{
    var customers=await Customer.findAll();
    return {
        status: 200,
        message: {
            message: "Ok",
            data: customers
        }
    }
    
}