import { Customer } from "../../../models/customers.js"

export const createCustomers=async(params)=>{
    const transaction= params.transaction;
    await Customer.bulkCreate(params.body);
    await transaction.commit();
    return {
        status: 201,
        message: {
            message: "Created"
        }
    }
    
}