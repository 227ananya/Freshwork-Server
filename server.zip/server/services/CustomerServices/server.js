import * as express from 'express'
import { controllerHandler } from '../../shared/controllerHandler.js';
import { createCustomers } from './controller/createCustomers.js';
import { getCustomers } from './controller/getCustomers.js';
const router = express.Router();

router.post('/createCustomers',(req,res)=> {
    controllerHandler({
        req,res,
        controller: createCustomers
    })
})
router.get('/getCustomers',(req,res)=> {
    controllerHandler({
        req,res,
        controller: getCustomers
    })
})

const customerRouter=router;
export {customerRouter};
