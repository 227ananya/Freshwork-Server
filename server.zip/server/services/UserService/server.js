import * as express from 'express'
import { controllerHandler } from '../../shared/controllerHandler.js';
import { signupSchema } from './validation/signupSchema.js';
import { signinSchema } from './validation/signinSchema.js';
import { signup } from './controller/signup.js';
import { signin } from './controller/signin.js';
const router = express.Router();

router.post('/signup',(req,res)=> {
    controllerHandler({
        req,res,
        schema: signupSchema,
        controller: signup
    })
})

router.post('/signin',(req,res)=> {
    controllerHandler({
        req,res,
        schema: signinSchema,
        controller: signin
    })
})

const userRouter=router;
export {userRouter};
