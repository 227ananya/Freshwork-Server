import { generateSha256Password } from "../../../shared/generateSha256Password.js";
import {User} from "../../../models/module.js";
import pkg from 'jsonwebtoken';
const { sign } = pkg;
export const signin=async(params)=>{
    
    const existingUser= await User.findOne({
        where:{
            email: params.body.email,
            password: generateSha256Password(params.body.password)
        }
    });
    if(!existingUser) {
        return {
            status: 400,
            message: {
                message: "Credentials not matching.Please try again."
            }
        }
    } else {
        // Create an access token
        let token = sign(
            // tslint:disable-next-line:radix
            { id: existingUser.uuid,},
            process.env.SHA256_PASSWORD_SALT,
            { expiresIn: process.env.TOKEN_LIFE },
        );
        return {
            status: 200,
            message: {
                message: "Ok",
                token: "Bearer "+token
            }
        }
    }
    
}