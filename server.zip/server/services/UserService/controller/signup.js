import { generateSha256Password } from "../../../shared/generateSha256Password.js";
import {User} from "../../../models/module.js"
export const signup=async(params)=>{
    const transaction= params.transaction;
    const existingUser= await User.findOne({
        where:{
            email: params.body.email
        }
    });
    if(existingUser) {
        return {
            status: 400,
            message: {
                message: "User with this email Id Already exist."
            }
        }
    } else {
        var data={
            name: params.body.name,
            email: params.body.email,
            password: generateSha256Password(params.body.password)
        }
        await User.create(data, { transaction });
        await transaction.commit();
    
        return {
            status: 200,
            message: {
                message: "Ok"
            }
        }
    }
    
}